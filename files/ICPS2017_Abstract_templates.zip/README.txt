# Copyright 2017 ICPS Organizing Commmittee

These templates are provided for guidance only, in order to facilitate 
abstract submissions at the International Conference of Physics Students 
2017 (Torino, Italy). 

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Please visit www.icps2017.it for information on the International 
Conference of Physics Students 2017. 