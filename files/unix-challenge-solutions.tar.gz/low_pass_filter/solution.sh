touch data.txt && cat data1.txt data2.txt > data.txt && sort -g data.txt -o data.txt
sed -i '1i Freq(Hz)\tGain\tPhase(deg)' data.txt
sed -i 's/,/./g' data.txt
awk 'NR==1{ print };NR>1{ print $1, $2, $3 }' data.txt > newdata.txt && mv newdata.txt data.txt
awk 'NR==1{ print };NR>1{ print $1, exp(($2)*log(10)), $3 }' data.txt > newdata.txt && mv newdata.txt data.txt
awk 'NR==1{ print };NR>1{ printf("%d\t%.2f\t%.1f\n", $1, $2, $3) }' data.txt > newdata.txt && mv newdata.txt data.txt
sed -i -e '1i\\\begin{tabular}{ccc}' -e '$a\\\end{tabular}{ccc}' data.txt
sed -i -e "s/$(printf '\t')/ \& /g" -e "2,$(($(cat data.txt | wc -l) - 1)) s/$/ \\\\\\\/" data.txt
