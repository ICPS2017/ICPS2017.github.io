for file in WPPBSDevice*; do sed -i -e '1,17 s/^/# /' $file; done
for file in WPPBSDevice*; do sed -e 's/;/\t/g' $file; done
for file in WPPBSData*; do awk 'NR>10 { FS=";"; print FILENAME,$30,$31 }' $file | tail -n1 >> waists.txt; done; sed -i -e 's/WPPBSData//' -e 's/.csv//' waists.txt
awk '{ printf"%g\t%g\t%g\t%g\n", ($1+8)*2.5e-2, $2/2, $3/2, ($2+$3)/4 }' waists.txt
sed -i -e '1i # distance(cm) x_waist y_waist mean_waist' waists.txt 
