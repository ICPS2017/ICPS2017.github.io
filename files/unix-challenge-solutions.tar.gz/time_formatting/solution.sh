sed -e '1,4d' -e 's/\// /g' -e 's/:/ /g' data.txt | awk '{ printf "%d%d%d %f %g\n",$3,$2,$1,$4*3600+$5*60+$6,$7 }' > data.tmp && mv data.tmp data.txt
