# sed/awk/bash challenge

You are given six challenges: each challenge consists in one or
multiple tasks to be performed on real or simulated data. You can find
the tasks that you have to perform in CHALLENGE/task.txt.

You can start from the challenge that you want and go on according to
your interests.

You can work alone or in group, and you are also allowed to use the
internet in order to find the solution!

Feel free to ask any question during the challenge time, we can try to
help you if we can!

Some online resources that could help you:
- http://grymoire.com/Unix/sed.html
- https://www.gnu.org/software/sed/manual/sed.html
- http://grymoire.com/Unix/Awk.html
- https://www.gnu.org/software/gawk/manual/gawk.html
- http://staff.washington.edu/mjt29/teaching/PreMap/handouts/UnixHandout.pdf
